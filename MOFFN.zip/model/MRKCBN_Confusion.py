import torch
from timm import create_model
from torch import nn, device
from model.cross_attention import CrossAttentionBlock, CrossAttention
from model.mobileNet import MobileNetV3_Small, MobileNetV3_Small_confusion

device=torch.device("cuda"if torch.cuda.is_available() else "cpu")


class MRKCBN_Confusion(nn.Module):
    def __init__(self,device):
        super(MRKCBN_Confusion, self).__init__()
        self.device=device

        self.model=MobileNetV3_Small_confusion(num_classes=3).to(device)

        self.cross_attn=CrossAttention(
            1152, num_heads=8, qkv_bias=True, qk_scale=None, attn_drop=0.0, proj_drop=0.0).to(device)

        self.avgpool = nn.AdaptiveAvgPool1d(1).to(device)
        self.head = nn.Linear(1152, 3).to(device)

    def forward(self, x1,x2,x3):
        x1 = self.model(x1)
        x2 = self.model(x2)
        x3 = self.model(x3)

        combined_features = torch.cat((x1, x2, x3), dim=1)
        combined_features=self.cross_attn(combined_features)
        combined_features = self.avgpool(combined_features.transpose(1, 2))  # [8, 1152, 1]
        out = combined_features.view(combined_features.size(0), -1)
        out=self.head(out)

        # print("model(x):",x.shape)
        return out
