import torch
from torch import nn
import torch.nn.functional as F

class AttentionPooling(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(AttentionPooling, self).__init__()
        self.output_dim = output_dim
        self.attention_layer = nn.Linear(input_dim, 1)  # 注意力分数是单维度的
        self.output_layer = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        # x: 输入序列，假设其形状为 [batch_size, num_heads, seq_length, input_dim]
        batch_size, num_heads, seq_length, input_dim = x.size()

        # 计算每个头的注意力分数，输出应为 [batch_size, num_heads, seq_length]
        attention_scores = self.attention_layer(x).squeeze(-1)  # 移除最后一个维度
        attention_scores = F.softmax(attention_scores, dim=-1)  # 在seq_length上归一化

        # 使用注意力分数对输入序列进行加权聚合，聚合在seq_length上进行
        # 形状变为 [batch_size, num_heads, seq_length, input_dim] -> [batch_size, num_heads, input_dim]
        pooled_output = (attention_scores.unsqueeze(-1) * x).sum(dim=2)

        # 通过输出层生成最终的输出
        # 形状变为 [batch_size, num_heads, input_dim] -> [batch_size, num_heads, output_dim]
        output = self.output_layer(pooled_output)

        # 需要保持 seq_length 维度不变，所以需要调整输出的形状
        # 这里我们通过重复的方式恢复 seq_length 维度
        output = output.unsqueeze(2).expand(-1, -1, seq_length, -1)

        return output