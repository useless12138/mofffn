import math
import random
import torch
import torch.nn as nn
import numpy as np
import cv2
import os
import argparse

from PIL import Image
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Dataset
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

from model.MRKCBN_Confusion import MRKCBN_Confusion
from model.mobileNet import MobileNetV3_Small  # 确保这个路径正确
from torchutils import get_torch_transforms

import seaborn as sns

# criterion = FocalLoss(class_num=3)
criterion=nn.CrossEntropyLoss()

class CustomImageFolder(Dataset):
    def __init__(self, root, transform=None):
        self.root = root
        self.transform = transform
        self.classes = ['0', '1', '2']  # 定义所有类别的名称
        self.class_to_idx = {class_name: idx for idx, class_name in enumerate(self.classes)}
        self.images = []
        self.labels = []

        for label in self.classes:
            folder_name = os.path.join(self.root, label)
            if os.path.isdir(folder_name):
                for img in os.listdir(folder_name):
                    img_path = os.path.join(folder_name, img)
                    self.images.append(img_path)
                    self.labels.append(self.class_to_idx[label])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image, label

def normalize_confusion_matrix(cm, axis=1):
    cm = cm.astype('float')
    cm_sum = np.sum(cm, axis=axis, keepdims=True)
    np.divide(cm, cm_sum, out=cm, where=cm_sum != 0)
    return cm

def plot_confusion_matrix(cm, labels, title='Composite', cmap=plt.cm.Blues):
    normalized_cm = normalize_confusion_matrix(cm)
    plt.figure(figsize=(8, 6))
    sns.heatmap(normalized_cm, annot=True, fmt='.2f', cmap=cmap, xticklabels=labels, yticklabels=labels)
    plt.title(title)
    plt.xlabel('Predicted labels')
    plt.ylabel('True labels')
    savepath = r"F:\20130312\STSTNet-master\STSTNet-master\save\matrix_pictures" + '/' + title + '.jpg'
    plt.savefig(savepath)
    plt.show()

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# 测试代码的配置
def test_model(model, test_loader, u_test_loader, v_test_loader, device):
    model.eval()  # 设置为评估模式
    test_loss = 0
    correct = 0
    total = 0
    num_val_examples = 0
    total_gt = []
    total_pred = []

    with torch.no_grad():  # 不计算梯度，节省计算资源
        for (data1, target1), (data2, target2), (data3, target3) in zip(test_loader, u_test_loader, v_test_loader):
            data1, target1 = data1.to(device), target1.to(device)
            data2, target2 = data2.to(device), target2.to(device)
            data3, target3 = data3.to(device), target3.to(device)
            yhat = model(data1, data2, data3)
            loss = criterion(yhat, target1)

            test_loss += loss.data.item() * data1.size(0)
            correct += (torch.max(yhat, 1)[1] == target1).sum().item()
            num_val_examples += data1.shape[0]

            total_pred.extend(torch.max(yhat, 1)[1].tolist())
            total_gt.extend(target1.tolist())

        accuracy = correct / num_val_examples
        test_loss = test_loss / len(test_loader.dataset)

    return accuracy, test_loss, total_gt, total_pred

def confusionMatrix(gt, pred, labels):
    print("gt:", gt)
    print("pred:",pred)
    cm = confusion_matrix(gt, pred, labels=labels)
    f1_score, average_recall = compute_f1_and_recall(cm, labels)
    return f1_score, average_recall, cm

def compute_f1_and_recall(cm, labels):
    TP = np.diag(cm)
    FP = np.sum(cm, axis=1) - TP
    FN = np.sum(cm, axis=0) - TP
    f1_scores = []
    recall_scores = []
    for i, label in enumerate(labels):
        if (2 * TP[i] + FP[i] + FN[i]) > 0:
            f1_scores.append((2 * TP[i]) / (2 * TP[i] + FP[i] + FN[i]))
        if (cm.sum(axis=0)[i] > 0):
            recall_scores.append(TP[i] / cm.sum(axis=0)[i])
    return np.mean(f1_scores), np.mean(recall_scores)

def recognition_evaluation(final_gt, final_pred, labels):
    f1_list = []
    ar_list = []
    for emotion_index in labels:
        gt_recog = [1 if x == emotion_index else 0 for x in final_gt]
        pred_recog = [1 if x == emotion_index else 0 for x in final_pred]
        f1, ar, _ = confusionMatrix(gt_recog, pred_recog, [0, 1])
        f1_list.append(f1)
        ar_list.append(ar)
    return np.mean(f1_list), np.mean(ar_list)

def save_model_summary(model, file_path):
    # 打印和保存模型的层级信息
    with open(file_path, 'w') as f:
        # 遍历模型的每一层，并输出层级信息
        for name, layer in model.named_modules():
            layer_info = f"Layer: {name} | Type: {layer.__class__.__name__}\n"
            print(layer_info)
            f.write(layer_info)

        f.write("\n")
        # 获取模型的总参数数量并保存
        total_params = sum(p.numel() for p in model.parameters())
        total_trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        param_info = f"Total parameters: {total_params}\nTrainable parameters: {total_trainable_params}\n"
        print(param_info)
        f.write(param_info)

def main():
    # 设备配置
    set_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    accuracys = []
    UF1s = []
    UARs = []
    # 总混淆矩阵
    total_cm = np.zeros((3, 3))
    # 加载模型
    model = MRKCBN_Confusion(device).to(device)
    model = model.to(device)
    model_path = "model_summary.txt"
    save_model_summary(model, model_path)
    weight_base_path = ''
    test_base_dir = ''
    subnames = os.listdir(test_base_dir)

    X_test = []
    y_test = []

    labels = [0, 1, 2]
    for n_subName in subnames:
        weight_path = weight_base_path + '/' + f'{n_subName}_best.pth'
        # weight_path = weight_base_path + '/' + f'{subname}_epoch_500.pth'

        print(weight_path)


        model.load_state_dict(torch.load(weight_path))  # 加载训练好的权重

        # Get test dataset
        expression = os.listdir(test_base_dir + '/' + n_subName + '/samm_one_cross/test')
        test_dir = test_base_dir + '/' + n_subName + '/samm_one_cross/test'

        for n_expression in expression:
            img = os.listdir(test_base_dir + '/' + n_subName + '/samm_one_cross/test/' + n_expression)

            for n_img in img:
                y_test.append(int(n_expression))
                X_test.append(
                    cv2.imread(
                        test_base_dir + '/' + n_subName + '/samm_one_cross/test/' + n_expression + '/' + n_img))

        # Get u_test dataset
        u_expression = os.listdir(test_base_dir + '/' + n_subName + '/samm_one_cross_u/test')
        u_test_dir = test_base_dir + '/' + n_subName + '/samm_one_cross_u/test'

        for n_expression in u_expression:
            img = os.listdir(test_base_dir + '/' + n_subName + '/samm_one_cross_u/test/' + n_expression)

            for n_img in img:
                y_test.append(int(n_expression))
                X_test.append(cv2.imread(
                    test_base_dir + '/' + n_subName + '/samm_one_cross_u/test/' + n_expression + '/' + n_img))

        # Get v_test dataset
        v_expression = os.listdir(test_base_dir + '/' + n_subName + '/samm_one_cross_v/test')
        v_test_dir = test_base_dir + '/' + n_subName + '/samm_one_cross_v/test'

        for n_expression in v_expression:
            img = os.listdir(test_base_dir + '/' + n_subName + '/samm_one_cross_v/test/' + n_expression)

            for n_img in img:
                y_test.append(int(n_expression))
                X_test.append(cv2.imread(
                    test_base_dir + '/' + n_subName + '/samm_one_cross_v/test/' + n_expression + '/' + n_img))
        # Get train dataset


        data_transforms = get_torch_transforms(img_size=224)  # 获取图像预处理方式

        test_dataset = CustomImageFolder(test_dir, data_transforms['val'])
        test_loader = DataLoader(test_dataset, batch_size=256, shuffle=False, num_workers=2)
        u_test_dataset = CustomImageFolder(u_test_dir, data_transforms['val'])
        u_test_loader = DataLoader(u_test_dataset, batch_size=256, shuffle=False, num_workers=2)
        v_test_dataset = CustomImageFolder(v_test_dir, data_transforms['val'])
        v_test_loader = DataLoader(v_test_dataset, batch_size=256, shuffle=False, num_workers=2)

        accuracy, test_loss, total_gt, total_pred = test_model(model, test_loader, u_test_loader, v_test_loader, device)
        accuracys.append(accuracy)
        # 计算当前子集的混淆矩阵，并将其累加到总混淆矩阵中
        _, _, cm = confusionMatrix(total_gt, total_pred, labels)
        total_cm += cm
        UF1, UAR = recognition_evaluation(total_gt, total_pred, labels)
        UF1s.append(UF1)
        UARs.append(UAR)
        print("accuracy:", accuracy)
        print("UF1:", UF1)
        print("UAR:", UAR)
    average_accuracy = sum(accuracys) / len(accuracys) if accuracys else 0
    average_UF1 = sum(UF1s) / len(UF1s) if UF1s else 0
    average_UAR = sum(UARs) / len(UARs) if UARs else 0
    print("average_accuracy:", average_accuracy)
    print("average_UF1:", average_UF1)
    print("average_UAR:", average_UAR)
    # 在循环结束后，绘制总的混淆矩阵
    plot_confusion_matrix(total_cm, labels)

if __name__ == '__main__':
    main()
